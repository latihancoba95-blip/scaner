<script setup>
import { BrowserQRCodeReader } from '@zxing/browser'
import { ref, onMounted, onBeforeUnmount, nextTick, watch } from 'vue'
import axios from 'axios'

const result = ref('')
const status = ref('')

const isPromptOpen = ref(false)
const pendingId = ref('')
const promptSession = ref(0) // untuk force remount modal
const selectedKeterangan = ref(null)
const keteranganOptions = ['Toilet', 'Makan', 'Sholat', 'Istirahat', 'Lainnya']
const lainnyaInput = ref(null)

const statesMap = ref(loadStates()) // { [id]: { active: true, keterangan: '...' } }

function loadStates() {
  try { return JSON.parse(localStorage.getItem('breakStates') || '{}') } catch { return {} }
}

function saveStates() {
  localStorage.setItem('breakStates', JSON.stringify(statesMap.value))
}

const reader = new BrowserQRCodeReader()
let controls = null
let scanningLocked = false // cegah re-entrancy

const sendToGoogleSheet = async (id, keterangan) => {
  try {
    const { data } = await axios.post('http://localhost:3000/api/send', { id, keterangan })
    status.value = "Nama: " + data.row.nama +" | Devisi: " + data.row.divisi + " | Keterangan: " + data.keterangan + ' | Aksi: ' + data.action 
  } catch (error) {
    console.error(error)
    status.value = error.message
  }
}

const startScanning = async () => {
  try {
    const previewElem = document.getElementById('preview')
    controls = await reader.decodeFromVideoDevice(null, previewElem, handleScan)
  } catch (e) {
    console.error(e)
    status.value = 'Gagal mengakses kamera.'
  }
}

const stopScanning = () => {
  if (controls) {
    controls.stop()
    controls = null
  }
}

const openPrompt = async (id) => {
  pendingId.value = id
  selectedKeterangan.value = null
  promptSession.value++ // paksa remount modal & radio
  isPromptOpen.value = true
  await nextTick()
}

const closePrompt = () => {
  isPromptOpen.value = false
}

const handleScan = async (result, err) => {
  // callback resmi: (result, error, controls)
  if (err || scanningLocked || isPromptOpen.value) return
  if (!result) return

  const text = result.getText?.() || ''
  if (!text) return

  scanningLocked = true
  stopScanning()

  const st = statesMap.value[text]
  if (st && st.active) {
    // === KEMBALI ===
    await sendToGoogleSheet(text, st.keterangan)
    result.value = `${text} (kembali)`
    delete statesMap.value[text]
    saveStates()
    scanningLocked = false
    startScanning()
    return
  }

  // === KELUAR === (ID baru atau sudah reset)
  await openPrompt(text)
  scanningLocked = false
}

const autoConfirm = async (ket) => {
  if (!pendingId.value || !ket) return
  // kirim "keluar"
  await sendToGoogleSheet(pendingId.value, ket)
  result.value = `${pendingId.value} (keluar)`
  // set aktif utk ID ini
  statesMap.value[pendingId.value] = { active: true, keterangan: ket }
  saveStates()

  // bereskan UI + lanjut scan
  pendingId.value = ''
  closePrompt()
  startScanning()
}

// Watcher: radio berubah → auto kirim (kecuali 'Lainnya')
watch(selectedKeterangan, async (val) => {
  if (!isPromptOpen.value) return
  if (val === 'Lainnya') {
    await nextTick()
    lainnyaInput.value?.focus()
    return
  }
  if (val) await autoConfirm(val)
})

const confirmLainnyaIfReady = async (e) => {
  const val = (e?.target?.value || '').trim()
  if (val) {
    // setel selectedKeterangan dulu biar konsisten di state
    selectedKeterangan.value = val
    await autoConfirm(val)
  }
}

const handleEsc = (e) => {
  if (e.key === 'Escape' && isPromptOpen.value) {
    // batal pilih → lanjut scan lagi tanpa kirim
    closePrompt()
    pendingId.value = ''
    startScanning()
  }
}

onMounted(() => {
  startScanning()
  window.addEventListener('keydown', handleEsc)
})

onBeforeUnmount(() => {
  stopScanning()
  window.removeEventListener('keydown', handleEsc)
})
</script>

<template>
  <div class="p-4 flex flex-col items-center">
    <h1 class="text-xl font-bold mb-2">Scan QR Karyawan</h1>

    <video id="preview" class="w-full max-w-md border rounded-lg"></video>

    <!-- <p class="mt-4 text-lg">Terakhir: {{ result }}</p> -->
    <p class="text-green-600 font-semibold">{{ status }}</p>

    <!-- Modal: key supaya remount bersih setiap buka -->
    <div
      v-if="isPromptOpen"
      :key="promptSession"
      class="fixed inset-0 z-50 flex items-center justify-center"
      aria-modal="true"
      role="dialog"
    >
      <!-- Backdrop -->
      <div class="absolute inset-0 bg-black/50"></div>

      <!-- Card -->
      <div class="relative w-full max-w-md mx-4 rounded-xl bg-white shadow-lg p-5">
        <h2 class="text-lg font-semibold mb-3 text-gray-800">Pilih Keterangan (otomatis kirim)</h2>

        <div class="mb-4 text-sm text-gray-600">
          ID terdeteksi:
          <span class="font-mono font-medium text-gray-800">{{ pendingId }}</span>
        </div>

        <div class="space-y-2 max-h-60 overflow-auto">
          <label
            v-for="opt in keteranganOptions"
            :key="opt"
            class="flex items-center gap-3 p-2 rounded-lg border hover:bg-gray-50 cursor-pointer"
          >
            <input
              type="radio"
              class="accent-black"
              name="keterangan"
              :value="opt"
              v-model="selectedKeterangan"
            />
            <span class="text-sm text-gray-800">{{ opt }}</span>
          </label>

          <!-- Input 'Lainnya' --> 
          <div v-if="selectedKeterangan === 'Lainnya'" class="mt-2">
            <input
              ref="lainnyaInput"
              type="text"
              class="w-full border rounded-lg p-2"
              placeholder="Tuliskan keterangan lalu Enter"
              @keyup.enter="confirmLainnyaIfReady"
              @blur="confirmLainnyaIfReady"
            />
            <p class="text-xs text-gray-500 mt-1">Tekan Enter untuk mengirim.</p>
          </div>
        </div>

        <div class="mt-4 text-right">
          <button class="px-3 py-1 rounded-lg border hover:bg-gray-50" @click="closePrompt">
            Tutup
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
